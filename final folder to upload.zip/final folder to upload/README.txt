Project Title: Air Piano: Real-Time Finger Detection for Virtual Piano Playing

Team members and their individual contributions:

1. Vaibhav_24112, DM, gvaibhav@iisc.ac.in��
- Dataset Collection, Labeling, and Augmentation: responsible for collecting the images needed for the project.
- Labeled these images, assigning appropriate tags, and augmented the dataset by creating additional variations.
- Presentation and Report Making: took charge of preparing the presentation slides and writing the project report, ensuring that the team�s work was well-documented and clearly communicated.

2. Siddharth_24857, DM, siddhartha1@iisc.ac.in
- Idea Conceptualisation for Air Piano: came up with the original concept for the Air Piano. 
- Colab Model Training and Quantization: Trained the model using Colab and optimized it by making it smaller, so it runs quickly on the device.
- Brought model size to 96.40 kb with 78.76% accuracy.

3. Sudhansu_24177, DM, sudhansu2024@iisc.ac.in�
- Making It Feel Like a Real Piano: figured out a way for the piano to tell when you�re �pressing� or �lifting� a key. It checks how close and where your finger is to the camera, so playing feels smooth and natural. 
- Optimization: Enhanced model performance by refining datasets and model parameters, cutting latency with efficient image preprocessing. 
- Gesture-to-Audio Integration: developed the pipeline for receiving predicted outputs from model and mapping them to audio of piano keys
- Integrated a feature that activate the piano with a �welcome message� when you show your fist. 
